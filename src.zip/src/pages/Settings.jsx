// src/pages/Settings.jsx
// Restored original Settings with your preferences logic; adds Labels tab,
// "Delete Grow Data Only", a safer Delete All flow with backup + type-to-confirm,
// and a desktop-only "Check for updates" button in the Advanced tab.

import React, { useCallback, useEffect, useState } from "react";
import { auth, db } from "../firebase-config";
import { doc, getDoc, setDoc, collection, getDocs } from "firebase/firestore";
import { deleteAllUserData, clearAllLocalCaches, deleteGrowDataOnly } from "../lib/delete-all";

/** Accent palette */
const ACCENTS = [
  { id: "emerald", label: "Emerald", hex600: "#059669" },
  { id: "violet", label: "Violet", hex600: "#7c3aed" },
  { id: "amber", label: "Amber", hex600: "#d97706" },
  { id: "rose", label: "Rose", hex600: "#e11d48" },
  { id: "slate", label: "Slate", hex600: "#475569" },
  { id: "teal", label: "Teal", hex600: "#0d9488" },
  { id: "indigo", label: "Indigo", hex600: "#4f46e5" },
  { id: "sky", label: "Sky", hex600: "#0284c7" },
];

const MODES = [
  { id: "system", label: "System" },
  { id: "light", label: "Light" },
  { id: "dark", label: "Dark" },
];

const TABS = [
  { id: "general", label: "General" },
  { id: "labels", label: "Labels" },
  { id: "data", label: "Data" },
  { id: "adv", label: "Advanced" },
];

const defaultPrefs = {
  mode: "system",
  accent: "emerald",
  themeStyle: "default", // "default" | "chaotic"
  stageReminders: false,
  taskDigestTime: "09:00",
  stageMaxDays: { Inoculated: 0, Fruiting: 0 },
  temperatureUnit: "F",
  autoConvertEnvNotes: true,
  guideEnabled: true,
};

// LocalStorage keys used by LabelPrint.jsx
const LS_LABEL_TEMPLATE = "labels.template"; // "5160" | "5167"
const LS_LABEL_CODE = "labels.codeType"; // "qr" | "none"
const LS_LABEL_GRID = "labels.gridOverlay"; // "1" | "0"
const LS_WM_ENABLED = "labels.watermark.enabled"; // "1" | "0"
const LS_WM_URL = "labels.watermark.url"; // string

function applyThemeDOM(prefs) {
  const root = document.documentElement;
  const mq = window.matchMedia?.("(prefers-color-scheme: dark)");
  const isSystemDark = mq ? mq.matches : false;
  const dark = prefs.mode === "dark" || (prefs.mode === "system" && isSystemDark);
  root.classList.toggle("dark", !!dark);
  [
    "theme-emerald",
    "theme-violet",
    "theme-amber",
    "theme-rose",
    "theme-slate",
    "theme-teal",
    "theme-indigo",
    "theme-sky",
    "theme-chaotic",
  ].forEach((c) => root.classList.remove(c));
  root.classList.add(`theme-${prefs.accent || "emerald"}`);
}

function syncThemeStyle(style) {
  const enable = style === "chaotic";
  const root = document.documentElement;
  root.classList.toggle("bg-chaotic", enable);
  try {
    localStorage.setItem("cn_theme_style", enable ? "chaotic" : "default");
  } catch {}
}

export default function Settings({
  preferences: externalPrefs,
  onSavePreferences,
  onExportJSON, // if provided, used for backup download
  onImportJSON,
  onClearAllData,
}) {
  const [activeTab, setActiveTab] = useState("general");
  const [prefs, setPrefs] = useState(defaultPrefs);
  const [busy, setBusy] = useState(false);
  const uid = auth.currentUser?.uid || null;

  // Delete-all confirmation modal state
  const [showDeleteAllModal, setShowDeleteAllModal] = useState(false);
  const [typedConfirm, setTypedConfirm] = useState("");

  // Simple status for updater button
  // null | "checking" | "available" | "none" | "error"
  const [updateStatus, setUpdateStatus] = useState(null);

  // ---- Labels state (kept in this file; read by LabelPrint via LS) ----
  const [labelTemplate, setLabelTemplate] = useState(() => {
    try {
      return localStorage.getItem(LS_LABEL_TEMPLATE) || "5160";
    } catch {}
    return "5160";
  });
  const [labelCode, setLabelCode] = useState(() => {
    try {
      return localStorage.getItem(LS_LABEL_CODE) || "qr";
    } catch {}
    return "qr";
  });
  const [labelGrid, setLabelGrid] = useState(() => {
    try {
      return localStorage.getItem(LS_LABEL_GRID) === "1";
    } catch {}
    return false;
  });
  const [wmEnabled, setWmEnabled] = useState(() => {
    try {
      return localStorage.getItem(LS_WM_ENABLED) !== "0";
    } catch {}
    return true;
  });
  const [wmUrl, setWmUrl] = useState(() => {
    try {
      return localStorage.getItem(LS_WM_URL) || "";
    } catch {}
    return "";
  });

  // ---- Initial load: prefs + labels (Firestore mirrors) ----
  useEffect(() => {
    let isMounted = true;
    (async () => {
      let next = defaultPrefs;

      if (externalPrefs) {
        next = { ...defaultPrefs, ...externalPrefs };
      } else if (!uid) {
        try {
          const ls = localStorage.getItem("preferences");
          if (ls) next = { ...defaultPrefs, ...JSON.parse(ls) };
        } catch {}
      } else {
        const ref = doc(db, "users", uid, "settings", "preferences");
        const snap = await getDoc(ref);
        next = snap.exists() ? { ...defaultPrefs, ...snap.data() } : defaultPrefs;
        if (!snap.exists()) await setDoc(ref, next, { merge: true });
      }

      // Theme style local override
      try {
        const localStyle = localStorage.getItem("cn_theme_style");
        if (localStyle) next = { ...next, themeStyle: localStyle };
      } catch {}

      // If Firestore has labels, mirror them locally
      const labels = (next && next.labels) || {};
      if (typeof labels === "object") {
        if (typeof labels.template === "string") setLabelTemplate(labels.template === "5167" ? "5167" : "5160");
        if (typeof labels.code === "string") setLabelCode(labels.code === "none" ? "none" : "qr");
        if (typeof labels.grid === "boolean") setLabelGrid(!!labels.grid);
        if (typeof labels.watermark === "boolean") setWmEnabled(!!labels.watermark);
        if (typeof labels.watermarkUrl === "string") setWmUrl(labels.watermarkUrl || "");
      }

      if (isMounted) {
        setPrefs(next);
        applyThemeDOM(next);
        syncThemeStyle(next.themeStyle);
      }
    })();
    return () => {
      isMounted = false;
    };
  }, [uid, externalPrefs]);

  // ---- Persist Labels to localStorage immediately on change ----
  useEffect(() => {
    try {
      localStorage.setItem(LS_LABEL_TEMPLATE, labelTemplate);
    } catch {}
  }, [labelTemplate]);
  useEffect(() => {
    try {
      localStorage.setItem(LS_LABEL_CODE, labelCode);
    } catch {}
  }, [labelCode]);
  useEffect(() => {
    try {
      localStorage.setItem(LS_LABEL_GRID, labelGrid ? "1" : "0");
    } catch {}
  }, [labelGrid]);
  useEffect(() => {
    try {
      localStorage.setItem(LS_WM_ENABLED, wmEnabled ? "1" : "0");
    } catch {}
  }, [wmEnabled]);
  useEffect(() => {
    try {
      localStorage.setItem(LS_WM_URL, wmUrl || "");
    } catch {}
  }, [wmUrl]);

  // ---- Save core prefs (theme, units, etc.) ----
  const savePrefs = useCallback(
    async (next) => {
      setPrefs(next);
      try {
        localStorage.setItem("preferences", JSON.stringify(next));
      } catch {}
      if (onSavePreferences) {
        onSavePreferences(next);
      } else {
        applyThemeDOM(next);
        syncThemeStyle(next.themeStyle);
        if (uid) await setDoc(doc(db, "users", uid, "settings", "preferences"), next, { merge: true });
      }
    },
    [onSavePreferences, uid]
  );

  const setMode = (modeId) => savePrefs({ ...prefs, mode: modeId });
  const setAccent = (accentId) => {
    const exists = ACCENTS.some((a) => a.id === accentId);
    const id = exists ? accentId : "emerald";
    try {
      localStorage.setItem("cn_last_accent", id);
    } catch {}
    savePrefs({ ...prefs, accent: id });
  };
  const setThemeStyle = (styleId) => {
    let style = styleId === "chaotic" ? "chaotic" : "default";
    if (style === "default") {
      try {
        const last = localStorage.getItem("cn_last_accent");
        if (last && last !== prefs.accent) {
          savePrefs({ ...prefs, themeStyle: style, accent: last });
          return;
        }
      } catch {}
    }
    savePrefs({ ...prefs, themeStyle: style });
  };

  // Units
  const setTempUnit = (u) => savePrefs({ ...prefs, temperatureUnit: u === "C" ? "C" : "F" });
  const setAutoConvert = (en) => savePrefs({ ...prefs, autoConvertEnvNotes: !!en });

  // Reminders
  const setRemindersEnabled = (en) => savePrefs({ ...prefs, stageReminders: !!en });
  const setDigestTime = (hhmm) => savePrefs({ ...prefs, taskDigestTime: hhmm || "09:00" });
  const setStageDays = (stage, days) => {
    const n = Math.max(0, Number(days) || 0);
    savePrefs({ ...prefs, stageMaxDays: { ...(prefs.stageMaxDays || {}), [stage]: n } });
  };
  const clearFired = () => {
    try {
      localStorage.removeItem("remindersFired_v1");
    } catch {}
  };
  const sendTest = () => {
    window.dispatchEvent(
      new CustomEvent("cn-test-reminder", {
        detail: { title: "CNM — test reminder", body: "If you can see this, reminders can display on this device." },
      })
    );
  };
  const setGuideEnabled = (enabled) => savePrefs({ ...prefs, guideEnabled: !!enabled });

  // ---- Backup JSON (used if onExportJSON not provided) ----
  const generateBackupJSON = useCallback(async () => {
    if (!uid) throw new Error("Not signed in.");
    const data = {};
    const subs = [
      "grows",
      "recipes",
      "supplies",
      "tasks",
      "timeline",
      "analytics",
      "events",
      "notes",
      "images",
      "labels",
      "strains",
      "audit",
      "logs",
      "settings",
    ];
    for (const sub of subs) {
      const snap = await getDocs(collection(db, "users", uid, sub));
      data[sub] = snap.docs.map((d) => ({ id: d.id, ...d.data() }));
    }
    const blob = new Blob([JSON.stringify(data, null, 2)], { type: "application/json" });
    const url = URL.createObjectURL(blob);
    const a = document.createElement("a");
    a.href = url;
    a.download = `myco-backup-${new Date().toISOString().slice(0, 10)}.json`;
    a.click();
    URL.revokeObjectURL(url);
  }, [uid]);

  // ---- Danger-zone helpers ----
  async function handleClearLocal() {
    setBusy(true);
    try {
      await clearAllLocalCaches();
      alert("Local cache cleared. You can refresh the page.");
    } catch (e) {
      console.error(e);
      try {
        localStorage.clear();
      } catch {}
      alert("Local cache clearing hit an error; best-effort fallback applied.");
    } finally {
      setBusy(false);
    }
  }

  async function handleDeleteGrowOnly() {
    if (!uid) return alert("You must be signed in.");
    const ok = window.confirm(
      "Delete ONLY grow data (grows, tasks, timeline, analytics, events, notes, images)? Recipes & supplies will remain."
    );
    if (!ok) return;
    setBusy(true);
    try {
      const res = await deleteGrowDataOnly();
      alert(`Grow data deleted. Firestore docs removed: ${res.deleted}`);
    } catch (e) {
      console.error(e);
      alert("Failed to delete grow data.");
    } finally {
      setBusy(false);
    }
  }

  // New Delete-All flow: backup prompt + type-to-confirm modal
  function handleDeleteAll() {
    if (typeof onClearAllData === "function") return onClearAllData();
    setShowDeleteAllModal(true);
    setTypedConfirm("");
  }

  async function confirmDeleteAll() {
    if (typedConfirm !== "DELETE") return;
    setBusy(true);
    try {
      const result = await deleteAllUserData();
      alert(
        `Deleted your data.\nFirestore docs removed: ${result.deleted}\nStorage purge attempted: ${
          result.deletedFiles ? "yes" : "skipped/disabled"
        }\n\nRefresh the page to start clean.`
      );
    } catch (e) {
      console.error(e);
      alert("Failed to delete all data. Are you signed in?");
    } finally {
      setBusy(false);
      setShowDeleteAllModal(false);
      setTypedConfirm("");
    }
  }

  // Desktop-only: check for updates via Tauri updater plugin (no-op in web builds)
  const handleCheckForUpdates = async () => {
    try {
      // Guard: only run in Tauri desktop
      const tauri = typeof window !== "undefined" ? window.__TAURI__ : null;
      if (!tauri || !tauri.core || typeof tauri.core.invoke !== "function") {
        alert("Check for updates is only available in the installed desktop app.");
        return;
      }

      setUpdateStatus("checking");

      // Call the updater plugin command.
      // This mirrors the @tauri-apps/plugin-updater `check()` behavior.
      const result = await tauri.core.invoke("plugin:updater|check");

      console.log("Updater check result:", result);

      // Try to support different shapes defensively
      const available =
        (result && typeof result === "object" && "available" in result && !!result.available) ||
        (result && typeof result === "object" && result.response && result.response.available);

      if (available) {
        setUpdateStatus("available");
        alert(
          "An update is available.\nThe updater will follow your configured behavior (e.g., download and prompt inside the desktop app)."
        );
      } else {
        setUpdateStatus("none");
        alert("You are already on the latest desktop version.");
      }
    } catch (err) {
      console.error("Update check failed:", err);
      setUpdateStatus("error");
      alert("Couldn't check for updates. Make sure you're online and that updater is configured.");
    }
  };

  // Derived for reminders UI
  const remindersOn = !!prefs.stageReminders;
  const digestTime = String(prefs.taskDigestTime || "09:00");
  const daysInoc = Number(prefs.stageMaxDays?.Inoculated || 0);
  const daysFruit = Number(prefs.stageMaxDays?.Fruiting || 0);

  // Save Label Defaults → mirror labels to preferences.labels in Firestore
  const saveLabelDefaults = async () => {
    try {
      const labels = {
        template: labelTemplate,
        code: labelCode,
        grid: !!labelGrid,
        watermark: !!wmEnabled,
        watermarkUrl: wmUrl || "",
      };
      // localStorage already updated by effects above
      if (uid) {
        await setDoc(doc(db, "users", uid, "settings", "preferences"), { labels }, { merge: true });
      } else {
        // also stash in local "preferences" blob for non-authed sessions
        const raw = localStorage.getItem("preferences");
        const cur = raw ? JSON.parse(raw) : {};
        const merged = { ...cur, labels };
        localStorage.setItem("preferences", JSON.stringify(merged));
      }
      alert("Label defaults saved.");
    } catch (e) {
      console.warn("Saving label defaults failed:", e);
      alert("Could not save label defaults. They still persist locally on this device.");
    }
  };

  return (
    <div className="mx-auto max-w-5xl px-4 py-6">
      <h1 className="text-2xl font-semibold mb-4">Settings</h1>

      <div role="tablist" aria-label="Settings Sections" className="flex flex-wrap gap-2 mb-6">
        {TABS.map((t) => (
          <button
            key={t.id}
            role="tab"
            aria-selected={activeTab === t.id}
            className={`chip ${activeTab === t.id ? "chip--active" : ""}`}
            onClick={() => setActiveTab(t.id)}
          >
            {t.label}
          </button>
        ))}
      </div>

      {/* GENERAL */}
      {activeTab === "general" && (
        <section role="tabpanel" aria-label="General settings" className="space-y-8">
          <div>
            <h2 className="text-lg font-medium mb-3">Theme Mode</h2>
            <div className="flex flex-wrap gap-2">
              {MODES.map((m) => (
                <button
                  key={m.id}
                  className={`chip ${prefs.mode === m.id ? "chip--active" : ""}`}
                  onClick={() => setMode(m.id)}
                >
                  {m.label}
                </button>
              ))}
            </div>
            <p className="text-sm text-slate-500 dark:text-slate-400 mt-2">
              <span className="font-medium">System</span> follows your OS preference automatically.
            </p>
          </div>

          {/* Theme Style */}
          <div>
            <h2 className="text-lg font-medium mb-3">Theme Style</h2>
            <div className="flex flex-wrap gap-2" data-tour="theme-style">
              <button
                className={`chip ${prefs.themeStyle !== "chaotic" ? "chip--active" : ""}`}
                onClick={() => setThemeStyle("default")}
              >
                Default
              </button>
              <button
                className={`chip ${prefs.themeStyle === "chaotic" ? "chip--active" : ""}`}
                onClick={() => setThemeStyle("chaotic")}
              >
                Chaotic
              </button>
            </div>
            <p className="text-sm text-slate-500 dark:text-slate-400 mt-2">
              Chaotic keeps the mountains background regardless of accent.
            </p>
          </div>

          {/* Accent */}
          <div>
            <h2 className="text-lg font-medium mb-3">Accent Color</h2>
            <div className="flex flex-wrap gap-2" data-tour="accent-color">
              {ACCENTS.map((a) => (
                <button
                  key={a.id}
                  className={`chip ${prefs.accent === a.id ? "chip--active" : ""}`}
                  onClick={() => setAccent(a.id)}
                >
                  <span className="h-2.5 w-2.5 rounded-full" style={{ backgroundColor: a.hex600 }} />
                  <span>{a.label}</span>
                </button>
              ))}
            </div>
            <p className="text-sm text-slate-500 dark:text-slate-400 mt-2">
              Change the accent without affecting the Chaotic background.
            </p>
          </div>

          {/* Guide toggle */}
          <div>
            <h2 className="text-lg font-medium mb-3">Guided tour &amp; Help menu</h2>
            <div className="flex flex-wrap items-center gap-2">
              <button
                className={`chip ${prefs.guideEnabled ? "chip--active" : ""}`}
                onClick={() => setGuideEnabled(true)}
              >
                On
              </button>
              <button
                className={`chip ${!prefs.guideEnabled ? "chip--active" : ""}`}
                onClick={() => setGuideEnabled(false)}
              >
                Off
              </button>
            </div>
            <p className="text-sm text-slate-500 dark:text-slate-400 mt-2">
              When Off, the bottom-left help button is hidden and onboarding will not auto-open.
            </p>
          </div>

          {/* Units */}
          <div>
            <h2 className="text-lg font-medium mb-3">Units</h2>
            <div className="flex flex-wrap items-center gap-2">
              <button
                className={`chip ${String(prefs.temperatureUnit || "F").toUpperCase() === "F" ? "chip--active" : ""}`}
                onClick={() => setTempUnit("F")}
              >
                Fahrenheit (°F)
              </button>
              <button
                className={`chip ${String(prefs.temperatureUnit || "F").toUpperCase() === "C" ? "chip--active" : ""}`}
                onClick={() => setTempUnit("C")}
              >
                Celsius (°C)
              </button>
            </div>

            <label className="mt-3 flex items-center gap-2 text-sm">
              <input
                type="checkbox"
                checked={!!prefs.autoConvertEnvNotes}
                onChange={(e) => setAutoConvert(e.target.checked)}
              />
              Also store a °C copy for analytics
            </label>
            <p className="text-xs text-slate-500 dark:text-slate-400 mt-1">
              Notes always save a canonical Fahrenheit value. Enabling this also saves a converted Celsius value.
            </p>
          </div>

          {/* Reminders */}
          <div>
            <h2 className="text-lg font-medium mb-3">Task Reminders</h2>
            <p className="text-sm text-slate-500 dark:text-slate-400 mb-3">
              Local (device-only) reminders for stage windows.
            </p>

            <div className="flex flex-wrap items-center gap-2 mb-3">
              <button
                className={`chip ${!remindersOn ? "chip--active" : ""}`}
                onClick={() => setRemindersEnabled(false)}
              >
                Off
              </button>
              <button
                className={`chip ${remindersOn ? "chip--active" : ""}`}
                onClick={() => setRemindersEnabled(true)}
              >
                On
              </button>
              <button className="btn-outline text-xs ml-2" onClick={sendTest}>
                Send test notification
              </button>
            </div>

            <div className="flex flex-wrap items-center gap-3 mb-3">
              <label className="text-sm text-slate-600 dark:text-slate-300">Daily digest time</label>
              <input
                type="time"
                value={digestTime}
                onChange={(e) => setDigestTime(e.target.value)}
                className="rounded-lg border border-zinc-300 dark:border-zinc-700 bg-white dark:bg-zinc-900 px-3 py-2 text-sm"
              />
            </div>

            <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
              <div className="flex items-center gap-2">
                <label className="w-36 text-sm text-slate-600 dark:text-slate-300">Inoculated (days)</label>
                <input
                  type="number"
                  min="0"
                  step="1"
                  value={Number.isFinite(daysInoc) ? daysInoc : 0}
                  onChange={(e) => setStageDays("Inoculated", e.target.value)}
                  className="w-28 rounded-lg border border-zinc-300 dark:border-zinc-700 bg-white dark:bg-zinc-900 px-3 py-2 text-sm"
                />
              </div>
              <div className="flex items-center gap-2">
                <label className="w-36 text-sm text-slate-600 dark:text-slate-300">Fruiting (days)</label>
                <input
                  type="number"
                  min="0"
                  step="1"
                  value={Number.isFinite(daysFruit) ? daysFruit : 0}
                  onChange={(e) => setStageDays("Fruiting", e.target.value)}
                  className="w-28 rounded-lg border border-zinc-300 dark:border-zinc-700 bg-white dark:bg-zinc-900 px-3 py-2 text-sm"
                />
              </div>
            </div>

            <div className="mt-3 flex flex-wrap items-center gap-2">
              <button type="button" className="btn-outline text-xs" onClick={clearFired}>
                Clear fired reminders
              </button>
              <span className="text-xs text-slate-500 dark:text-slate-400">
                (Only clears local “already notified” memory on this device)
              </span>
            </div>
          </div>
        </section>
      )}

      {/* LABELS */}
      {activeTab === "labels" && (
        <section role="tabpanel" aria-label="Label settings" className="space-y-6">
          <h2 className="text-lg font-medium">Label Defaults</h2>

          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            {/* Template */}
            <div className="space-y-2">
              <div className="text-sm opacity-70">Template</div>
              <select
                className="rounded border border-zinc-300 dark:border-zinc-800 bg-white dark:bg-zinc-900 px-3 py-2"
                value={labelTemplate}
                onChange={(e) => setLabelTemplate(e.target.value === "5167" ? "5167" : "5160")}
              >
                <option value="5160">Avery 5160 / 8160 (2.625″ × 1″)</option>
                <option value="5167">Avery 5167 (1.75″ × 0.5″)</option>
              </select>
            </div>

            {/* Code type */}
            <div className="space-y-2">
              <div className="text-sm opacity-70">Code Type</div>
              <select
                className="rounded border border-zinc-300 dark:border-zinc-800 bg-white dark:bg-zinc-900 px-3 py-2"
                value={labelCode}
                onChange={(e) => setLabelCode(e.target.value === "none" ? "none" : "qr")}
              >
                <option value="qr">QR</option>
                <option value="none">None</option>
              </select>
            </div>

            {/* Grid overlay */}
            <label className="inline-flex items-center gap-2 select-none">
              <input
                type="checkbox"
                className="h-4 w-4 align-middle"
                checked={labelGrid}
                onChange={(e) => setLabelGrid(e.target.checked)}
              />
              <span className="text-sm">Show grid overlay in preview</span>
            </label>

            {/* Watermark toggle */}
            <label className="inline-flex items-center gap-2 select-none">
              <input
                type="checkbox"
                className="h-4 w-4 align-middle"
                checked={wmEnabled}
                onChange={(e) => setWmEnabled(e.target.checked)}
              />
              <span className="text-sm">Enable watermark</span>
            </label>

            {/* Watermark URL */}
            <div className="space-y-2 md:col-span-2">
              <div className="text-sm opacity-70">Watermark URL (PNG/SVG/data:)</div>
              <input
                className="w-full rounded border border-zinc-300 dark:border-zinc-800 bg-white dark:bg-zinc-900 px-3 py-2"
                placeholder="https://… or data:image/png;base64,…"
                value={wmUrl}
                onChange={(e) => setWmUrl(e.target.value)}
              />
            </div>
          </div>

          <div>
            <button
              className="mt-2 px-3 py-2 rounded-lg bg-emerald-600 text-white hover:bg-emerald-700"
              onClick={saveLabelDefaults}
            >
              Save Label Defaults
            </button>
          </div>
        </section>
      )}

      {/* DATA */}
      {activeTab === "data" && (
        <section role="tabpanel" aria-label="Data settings" className="space-y-6">
          <div className="flex flex-wrap gap-2">
            <button type="button" className="btn btn-outline" onClick={onExportJSON}>
              Export JSON
            </button>
            <button type="button" className="btn" onClick={onImportJSON}>
              Import JSON
            </button>
            <button type="button" className="btn-accent" onClick={onExportJSON}>
              Backup Now
            </button>
          </div>
          <p className="text-sm text-slate-500 dark:text-slate-400">
            Exports and backups include grows, recipes, supplies, tasks, and preferences.
          </p>
        </section>
      )}

      {/* ADVANCED */}
      {activeTab === "adv" && (
        <section role="tabpanel" aria-label="Advanced settings" className="space-y-6">
          {/* Updates block */}
          <div className="space-y-3">
            <h2 className="text-lg font-medium">Desktop Updates</h2>
            <p className="text-sm text-slate-500 dark:text-slate-400">
              Check for updates to the installed desktop app. This only works in the Tauri desktop build.
            </p>
            <div className="flex flex-wrap items-center gap-2">
              <button
                type="button"
                className="btn"
                onClick={handleCheckForUpdates}
                disabled={busy || updateStatus === "checking"}
              >
                {updateStatus === "checking" ? "Checking…" : "Check for desktop updates"}
              </button>
              {updateStatus === "available" && (
                <span className="text-xs text-emerald-600 dark:text-emerald-400">
                  Update available — follow any prompts in the desktop app.
                </span>
              )}
              {updateStatus === "none" && (
                <span className="text-xs text-slate-500 dark:text-slate-400">
                  You&apos;re on the latest version.
                </span>
              )}
              {updateStatus === "error" && (
                <span className="text-xs text-rose-500 dark:text-rose-400">
                  Error checking for updates. See console for details.
                </span>
              )}
            </div>
          </div>

          {/* Danger Zone (unchanged logic) */}
          <div className="space-y-3">
            <h2 className="text-lg font-medium">Danger Zone</h2>
            <div className="flex flex-wrap gap-2">
              <button
                type="button"
                className="btn-outline"
                onClick={() => {
                  try {
                    localStorage.removeItem("preferences");
                  } catch {}
                  savePrefs(defaultPrefs);
                }}
                disabled={busy}
              >
                Reset Theme Preferences
              </button>
              <button type="button" className="btn" onClick={handleClearLocal} disabled={busy}>
                Clear Local Cache
              </button>

              {/* NEW: Delete Grow Data Only */}
              <button type="button" className="btn-accent" onClick={handleDeleteGrowOnly} disabled={busy}>
                Delete Grow Data Only
              </button>

              {/* Updated: Delete All Data opens modal */}
              <button type="button" className="btn-accent" onClick={handleDeleteAll} disabled={busy}>
                Delete All Data
              </button>
            </div>
            <p className="text-sm text-slate-500 dark:text-slate-400">
              Deleting data cannot be undone. Make sure you have an export/backup first.
            </p>
          </div>
        </section>
      )}

      {/* Delete-All Modal with Backup + Type-to-Confirm */}
      {showDeleteAllModal && (
        <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/50">
          <div className="w-full max-w-md rounded-lg bg-white p-6 shadow-lg dark:bg-zinc-900">
            <h3 className="text-lg font-semibold text-rose-600 dark:text-rose-400">Delete ALL Data</h3>
            <p className="mt-2 text-sm text-zinc-700 dark:text-zinc-300">
              This will permanently delete <strong>all</strong> your data (grows, recipes, supplies, labels, strains,
              tasks, Storage files, etc.). First, download a backup so you can re-import if needed.
            </p>

            <div className="mt-4 flex gap-2">
              <button
                className="btn-outline text-sm"
                onClick={async () => {
                  try {
                    if (typeof onExportJSON === "function") {
                      await onExportJSON();
                    } else {
                      await generateBackupJSON();
                    }
                  } catch (e) {
                    console.error(e);
                    alert("Backup failed. Try again.");
                  }
                }}
              >
                Download Backup
              </button>
            </div>

            <div className="mt-4">
              <label className="text-sm block mb-1">
                Type <span className="font-mono font-semibold">DELETE</span> to confirm
              </label>
              <input
                className="w-full rounded border border-zinc-300 bg-white px-3 py-2 text-sm dark:border-zinc-700 dark:bg-zinc-900"
                placeholder="DELETE"
                value={typedConfirm}
                onChange={(e) => setTypedConfirm(e.target.value)}
              />
            </div>

            <div className="mt-5 flex justify-end gap-2">
              <button
                className="btn-outline"
                onClick={() => {
                  setShowDeleteAllModal(false);
                  setTypedConfirm("");
                }}
              >
                Cancel
              </button>
              <button
                className="btn bg-rose-600 text-white hover:bg-rose-700 disabled:opacity-50"
                disabled={busy || typedConfirm !== "DELETE"}
                onClick={confirmDeleteAll}
              >
                Confirm Delete
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
}
